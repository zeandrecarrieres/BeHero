
exports.up = function(knex) {
  
};

exports.down = function(knex) {
  
};
